# FUTURE_CS_01
Web Application Security Testing Task for Future Interns Cybersecurity Internship
